## Packages
framer-motion | Smooth animations for grid cells and stars

## Notes
Tailwind Config - extend fontFamily to include 'Outfit' and 'Inter'
Theme colors: Navy Blue (#0f212e), Card (#213743), Green (#00e701)
